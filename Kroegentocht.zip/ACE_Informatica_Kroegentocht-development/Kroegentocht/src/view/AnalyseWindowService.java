/**
 * @Autor: Sven Noreillie
 * @Team: Team13
 * @Date: 05/11/2015
 * @Project: KroegenTocht
 * @Purpose: Marker interface om gekoppelde window te kunnen registreren in Guice container
 */

package view;

public interface AnalyseWindowService extends WindowService {

}
