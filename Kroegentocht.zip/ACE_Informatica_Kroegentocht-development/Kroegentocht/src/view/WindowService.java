/**
 * @Autor: Sven Noreillie
 * @Team: Team13
 * @Date: 05/11/2015
 * @Project: KroegenTocht
 * @Purpose: Hoofdinterface voor alle views
 */

package view;

public interface WindowService {

	void Show();
	void Hide();

}